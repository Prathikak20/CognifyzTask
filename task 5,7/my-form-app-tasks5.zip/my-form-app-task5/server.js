const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware to serve static files from 'public' folder
app.use(express.static('public'));

app.use(cors());
app.use(bodyParser.json());

// Temporary data store
let submissions = [];
let idCounter = 1;

// API endpoints

// Get all submissions
app.get('/api/submissions', (req, res) => {
  res.json(submissions);
});

// Add new submission
app.post('/api/submissions', (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and email required' });

  const newSubmission = { id: idCounter++, name, email };
  submissions.push(newSubmission);
  res.status(201).json(newSubmission);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
